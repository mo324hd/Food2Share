//
//  ViewController.swift
//  Emergency donation
//
//  Created by Ahmed Qamber on 27/12/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

