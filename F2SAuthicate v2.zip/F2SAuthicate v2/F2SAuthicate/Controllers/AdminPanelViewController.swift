//
//  AdminPanelViewController.swift
//  F2SAuthicate
//
//  Created by abdulaziz on 31/12/2025.
//

import UIKit

class AdminPanelViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
