//
//  ViewController.swift
//  F2SAuthicate
//
//  Created by abdulaziz on 18/12/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

